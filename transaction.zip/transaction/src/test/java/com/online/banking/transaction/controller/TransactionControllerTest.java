//package com.online.banking.transaction.controller;
//
//import com.online.banking.transaction.dto.TransactionHistorydto;
//import com.online.banking.transaction.dto.TransactionRequestDto;
//import com.online.banking.transaction.dto.TransactionResponseDto;
//import com.online.banking.transaction.service.TransactionService;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.PageImpl;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import java.math.BigDecimal;
//import java.time.LocalDate;
//import java.util.Collections;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.when;
//
//public class TransactionControllerTest {
//
//    @Mock
//    private TransactionService transactionService;
//
//    @InjectMocks
//    private TransactionController transactionController;
//
//    private TransactionRequestDto transactionRequestDto;
//    private TransactionResponseDto transactionResponseDto;
//
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.openMocks(this);
//
//        transactionRequestDto = new TransactionRequestDto();
//        transactionResponseDto = new TransactionResponseDto();
//
//        transactionResponseDto.setTransactionId(1L);
//        transactionResponseDto.setAmount(BigDecimal.valueOf(100));
//    }
//
//    @Test
//    public void testCreateTransaction() {
//        when(transactionService.createTransaction(any(TransactionRequestDto.class)))
//                .thenReturn(transactionResponseDto);
//
//        ResponseEntity<TransactionResponseDto> response = transactionController.createTransaction(transactionRequestDto);
//
//        assertEquals(HttpStatus.CREATED, response.getStatusCode());
//        assertEquals(transactionResponseDto, response.getBody());
//    }
//
//    @Test
//    public void testGetTransactionById() {
//        when(transactionService.getTransactionById(1L)).thenReturn(transactionResponseDto);
//
//        ResponseEntity<TransactionResponseDto> response = transactionController.getTransactionById(1L);
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(transactionResponseDto, response.getBody());
//    }
//
//    @Test
//    public void testGetAllTransactions() {
//        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "transactionDate"));
//        Page<TransactionResponseDto> page = new PageImpl<>(Collections.singletonList(transactionResponseDto));
//
//        when(transactionService.getAllTransactions(pageable)).thenReturn(page);
//
//        ResponseEntity<Page<TransactionResponseDto>> response = transactionController.getAllTransactions(0, 10, "transactionDate", "desc");
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(page, response.getBody());
//    }
//
//    @Test
//    public void testGetTransactionsByAccountId() {
//        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "transactionDate"));
//        Page<TransactionResponseDto> page = new PageImpl<>(Collections.singletonList(transactionResponseDto));
//
//        when(transactionService.getTransactionsByAccountId(1L, pageable)).thenReturn(page);
//
//        ResponseEntity<Page<TransactionResponseDto>> response = transactionController.getTransactionsByAccountId(1L, 0, 10, "transactionDate", "desc");
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(page, response.getBody());
//    }
//
//    @Test
//    public void testGetTransactionsByDateRange() {
//        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "transactionDate"));
//        Page<TransactionResponseDto> page = new PageImpl<>(Collections.singletonList(transactionResponseDto));
//        LocalDate startDate = LocalDate.now().minusDays(7);
//        LocalDate endDate = LocalDate.now();
//
//        when(transactionService.getTransactionsByDateRange(startDate, endDate, pageable)).thenReturn(page);
//
//        ResponseEntity<Page<TransactionResponseDto>> response = transactionController.getTransactionsByDateRange(startDate, endDate, 0, 10, "transactionDate", "desc");
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(page, response.getBody());
//    }
//
//    @Test
//    public void testGetTransactionHistory() {
//        LocalDate startDate = LocalDate.now().minusDays(7);
//        LocalDate endDate = LocalDate.now();
//        TransactionHistorydto historyDto = new TransactionHistorydto(BigDecimal.valueOf(1000), 10);
//
//        when(transactionService.getTransactionHistory(startDate, endDate)).thenReturn(historyDto);
//
//        ResponseEntity<TransactionHistorydto> response = transactionController.getTransactionHistory(startDate, endDate);
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(historyDto, response.getBody());
//    }
//}
