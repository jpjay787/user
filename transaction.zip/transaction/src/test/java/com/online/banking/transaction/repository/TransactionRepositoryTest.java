package com.online.banking.transaction.repository;

import com.online.banking.transaction.model.TransactionEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

public class TransactionRepositoryTest {

    @Mock
    private TransactionRepository transactionRepository;

    @InjectMocks
    private TransactionRepositoryTest transactionRepositoryTest;

    private TransactionEntity transactionEntity;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        transactionEntity = new TransactionEntity();
        transactionEntity.setTransactionId(1L);
        transactionEntity.setAccountId(1L);
        transactionEntity.setTransactionDate(LocalDate.now());
    }

    @Test
    public void testFindByTransactionId() {
        when(transactionRepository.findByTransactionId(anyLong())).thenReturn(Optional.of(transactionEntity));

        Optional<TransactionEntity> result = transactionRepository.findByTransactionId(1L);

        assertEquals(Optional.of(transactionEntity), result);
    }

    @Test
    public void testFindByAccountId() {
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "transactionDate"));
        Page<TransactionEntity> page = new PageImpl<>(Collections.singletonList(transactionEntity));

        when(transactionRepository.findByAccountId(anyLong(), any(Pageable.class))).thenReturn(page);

        Page<TransactionEntity> result = transactionRepository.findByAccountId(1L, pageable);

        assertEquals(page, result);
    }

    @Test
    public void testFindByTransactionDateBetween() {
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "transactionDate"));
        Page<TransactionEntity> page = new PageImpl<>(Collections.singletonList(transactionEntity));
        LocalDate startDate = LocalDate.now().minusDays(7);
        LocalDate endDate = LocalDate.now();

        when(transactionRepository.findByTransactionDateBetween(startDate, endDate, pageable)).thenReturn(page);

        Page<TransactionEntity> result = transactionRepository.findByTransactionDateBetween(startDate, endDate, pageable);

        assertEquals(page, result);
    }

    @Test
    public void testFindByTransactionDateBetweenWithoutPageable() {
        List<TransactionEntity> transactions = Collections.singletonList(transactionEntity);
        LocalDate startDate = LocalDate.now().minusDays(7);
        LocalDate endDate = LocalDate.now();

        when(transactionRepository.findByTransactionDateBetween(startDate, endDate)).thenReturn(transactions);

        List<TransactionEntity> result = transactionRepository.findByTransactionDateBetween(startDate, endDate);

        assertEquals(transactions, result);
    }
}
