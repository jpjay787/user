package com.online.banking.transaction.serviceImpl;

import com.online.banking.transaction.dto.TransactionHistorydto;
import com.online.banking.transaction.dto.TransactionRequestDto;
import com.online.banking.transaction.dto.TransactionResponseDto;
import com.online.banking.transaction.exception.TransactionException;
import com.online.banking.transaction.model.TransactionEntity;
import com.online.banking.transaction.repository.TransactionRepository;
import com.online.banking.transaction.serviceimpl.TransactionServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

public class TransactionServiceImplTest {

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private TransactionServiceImpl transactionService;

    private TransactionEntity transactionEntity;
    private TransactionRequestDto transactionRequestDto;
    private TransactionResponseDto transactionResponseDto;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        transactionEntity = new TransactionEntity();
        transactionEntity.setTransactionId(1L);
        transactionEntity.setAccountId(1L);
        transactionEntity.setTransactionDate(LocalDate.now());
        transactionEntity.setAmount(BigDecimal.valueOf(100.00));

        transactionRequestDto = new TransactionRequestDto();
        transactionRequestDto.setAccountId(1L);
        transactionRequestDto.setAmount(BigDecimal.valueOf(100.00));

        transactionResponseDto = new TransactionResponseDto();
        transactionResponseDto.setTransactionId(1L);
        transactionResponseDto.setAccountId(1L);
        transactionResponseDto.setTransactionDate(LocalDate.now());
        transactionResponseDto.setAmount(BigDecimal.valueOf(100.00));
    }

    @Test
    public void testCreateTransaction() {
        when(modelMapper.map(transactionRequestDto, TransactionEntity.class)).thenReturn(transactionEntity);
        when(transactionRepository.save(transactionEntity)).thenReturn(transactionEntity);
        when(modelMapper.map(transactionEntity, TransactionResponseDto.class)).thenReturn(transactionResponseDto);

        TransactionResponseDto result = transactionService.createTransaction(transactionRequestDto);

        assertEquals(transactionResponseDto, result);
    }

    @Test
    public void testGetTransactionById_Success() {
        when(transactionRepository.findByTransactionId(anyLong())).thenReturn(Optional.of(transactionEntity));
        when(modelMapper.map(transactionEntity, TransactionResponseDto.class)).thenReturn(transactionResponseDto);

        TransactionResponseDto result = transactionService.getTransactionById(1L);

        assertEquals(transactionResponseDto, result);
    }

    @Test
    public void testGetTransactionById_TransactionNotFound() {
        when(transactionRepository.findByTransactionId(anyLong())).thenReturn(Optional.empty());

        assertThrows(TransactionException.class, () -> transactionService.getTransactionById(1L));
    }

    @Test
    public void testGetAllTransactions() {
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "transactionDate"));
        Page<TransactionEntity> page = new PageImpl<>(Collections.singletonList(transactionEntity));

        when(transactionRepository.findAll(pageable)).thenReturn(page);
        when(modelMapper.map(transactionEntity, TransactionResponseDto.class)).thenReturn(transactionResponseDto);

        Page<TransactionResponseDto> result = transactionService.getAllTransactions(pageable);

        assertEquals(page.map(transaction -> transactionResponseDto), result);
    }

    @Test
    public void testGetTransactionsByAccountId() {
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "transactionDate"));
        Page<TransactionEntity> page = new PageImpl<>(Collections.singletonList(transactionEntity));

        when(transactionRepository.findByAccountId(anyLong(), any(Pageable.class))).thenReturn(page);
        when(modelMapper.map(transactionEntity, TransactionResponseDto.class)).thenReturn(transactionResponseDto);

        Page<TransactionResponseDto> result = transactionService.getTransactionsByAccountId(1L, pageable);

        assertEquals(page.map(transaction -> transactionResponseDto), result);
    }

    @Test
    public void testGetTransactionsByDateRange() {
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "transactionDate"));
        Page<TransactionEntity> page = new PageImpl<>(Collections.singletonList(transactionEntity));
        LocalDate startDate = LocalDate.now().minusDays(7);
        LocalDate endDate = LocalDate.now();

        when(transactionRepository.findByTransactionDateBetween(startDate, endDate, pageable)).thenReturn(page);
        when(modelMapper.map(transactionEntity, TransactionResponseDto.class)).thenReturn(transactionResponseDto);

        Page<TransactionResponseDto> result = transactionService.getTransactionsByDateRange(startDate, endDate, pageable);

        assertEquals(page.map(transaction -> transactionResponseDto), result);
    }

    @Test
    public void testGetTransactionHistory() {
        List<TransactionEntity> transactions = Collections.singletonList(transactionEntity);
        BigDecimal totalAmount = transactions.stream()
                .map(TransactionEntity::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        TransactionHistorydto history = new TransactionHistorydto(totalAmount, transactions.size());

        when(transactionRepository.findByTransactionDateBetween(any(LocalDate.class), any(LocalDate.class))).thenReturn(transactions);

        TransactionHistorydto result = transactionService.getTransactionHistory(LocalDate.now().minusDays(7), LocalDate.now());

        assertEquals(history, result);
    }
}
