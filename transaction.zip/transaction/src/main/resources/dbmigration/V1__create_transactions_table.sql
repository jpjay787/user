CREATE TABLE transactions (
    transaction_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    account_id BIGINT NOT NULL, -- Foreign key reference to account_entity
    amount DECIMAL(19, 2) NOT NULL,
    transaction_date DATE NOT NULL,
    CONSTRAINT fk_transaction_account FOREIGN KEY (account_id) REFERENCES account_entity(id));

