package com.online.banking.transaction.client;

import com.online.banking.transaction.dto.CardResponseDto;
import com.online.banking.transaction.dto.TransactionRequestDto;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

@Component
public class CardClient {

    @Autowired
    private RestTemplate restTemplate;

    private final String CARD_SERVICE_URL = "http://localhost:8082/api/cards"; // Update the base URL if required

    // Get card details by card number
    public CardResponseDto getCardNumber(String cardNumber) {
        String url = CARD_SERVICE_URL + "/cardNumber/" + cardNumber;
        ResponseEntity<CardResponseDto> response = restTemplate.getForEntity(url, CardResponseDto.class);
        return response.getBody();
    }

    // Debit card balance
    public CardResponseDto debitAmount(TransactionRequestDto transactionRequestDto) {
        String url = CARD_SERVICE_URL + "/debit/" + transactionRequestDto.getCardNumber() + "?amount=" + transactionRequestDto.getAmount();
        ResponseEntity<CardResponseDto> response = restTemplate.postForEntity(url, null, CardResponseDto.class);
        return response.getBody();
    }

    // Credit card balance
    public CardResponseDto creditAmount(TransactionRequestDto transactionRequestDto) {
        String url = CARD_SERVICE_URL + "/credit/" + transactionRequestDto.getCardNumber() + "?amount=" + transactionRequestDto.getAmount();
        ResponseEntity<CardResponseDto> response = restTemplate.postForEntity(url, null, CardResponseDto.class);
        return response.getBody();
    }
}
