package com.online.banking.transaction.client;


import com.online.banking.cards.dto.CardResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class CardClient {

    private final RestTemplate restTemplate;
    @Value("${service.card.url}")
    private String cardServiceUrl;


    public CardResponseDto getCardId(Long cardId) {
        String url = cardServiceUrl + "/" + cardId;
        return restTemplate.getForObject(url, CardResponseDto.class);
    }
}
