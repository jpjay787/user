package com.online.banking.transaction.repository;

import com.online.banking.transaction.model.TransactionEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface TransactionRepository extends JpaRepository<TransactionEntity, Long> {
    Optional<TransactionEntity> findByTransactionId(Long transactionId);
    Page<TransactionEntity> findByAccountId(Long accountId, Pageable pageable);
    Page<TransactionEntity> findByTransactionDateBetween(LocalDate startDate, LocalDate endDate, Pageable pageable);
    List<TransactionEntity> findByTransactionDateBetween(LocalDate startDate, LocalDate endDate);
}



