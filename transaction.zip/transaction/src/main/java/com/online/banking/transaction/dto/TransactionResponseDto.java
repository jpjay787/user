package com.online.banking.transaction.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransactionResponseDto {
    private Long transactionId;
    private Long cardId;
    private BigDecimal amount;
    private LocalDate transactionDate;
    private BigDecimal balance;
}
