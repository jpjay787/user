package com.online.banking.transaction.util;
public class ErrorUtil {
    public static final String TRANSACTION_NOT_FOUND = "Transaction not found.";
    public static final String GENERAL_ERROR_MESSAGE = " error: Please try again later.";
}