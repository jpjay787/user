package com.online.banking.transaction.service;

import com.online.banking.transaction.dto.TransactionHistorydto;
import com.online.banking.transaction.dto.TransactionRequestDto;
import com.online.banking.transaction.dto.TransactionResponseDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public interface TransactionService {
    TransactionResponseDto createTransaction(TransactionRequestDto transactionRequestDTO);
    TransactionResponseDto getTransactionById(Long transactionId);
    Page<TransactionResponseDto> getAllTransactions(Pageable pageable);
    Page<TransactionResponseDto> getTransactionsByCardNumber(String cardNumber, Pageable pageable);
    Page<TransactionResponseDto> getTransactionsByDateRange(LocalDate startDate, LocalDate endDate, Pageable pageable);
    TransactionHistorydto getTransactionHistory(LocalDate startDate, LocalDate endDate);
    public BigDecimal getCardBalance(String cardNumber);
}
