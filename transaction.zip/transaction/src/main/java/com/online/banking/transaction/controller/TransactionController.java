package com.online.banking.transaction.controller;

import com.online.banking.transaction.dto.TransactionHistorydto;
import com.online.banking.transaction.dto.TransactionRequestDto;
import com.online.banking.transaction.dto.TransactionResponseDto;
import com.online.banking.transaction.service.TransactionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
public class TransactionController {
    @Autowired
    private final TransactionService transactionService;
    @PostMapping
    public ResponseEntity<TransactionResponseDto> createTransaction( @RequestBody TransactionRequestDto transactionRequestDTO) {
        TransactionResponseDto response = transactionService.createTransaction(transactionRequestDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }


    @GetMapping("/{transactionId}")
    public ResponseEntity<TransactionResponseDto> getTransactionById(@PathVariable Long transactionId) {
        TransactionResponseDto response = transactionService.getTransactionById(transactionId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<Page<TransactionResponseDto>> getAllTransactions(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "transactionDate") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDirection) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.fromString(sortDirection), sortBy));
        Page<TransactionResponseDto> responses = transactionService.getAllTransactions(pageable);
        return new ResponseEntity<>(responses, HttpStatus.OK);
    }

    @GetMapping("/card/{cardId}")
    public ResponseEntity<Page<TransactionResponseDto>> getTransactionsByAccountId(
            @PathVariable String cardNumber,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "transactionDate") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDirection) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.fromString(sortDirection), sortBy));
        Page<TransactionResponseDto> responses = transactionService.getTransactionsByCardNumber(cardNumber, pageable);
        return new ResponseEntity<>(responses, HttpStatus.OK);
    }

    @GetMapping("/date-range")
    public ResponseEntity<Page<TransactionResponseDto>> getTransactionsByDateRange(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "transactionDate") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDirection) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.fromString(sortDirection), sortBy));
        Page<TransactionResponseDto> responses = transactionService.getTransactionsByDateRange(startDate, endDate, pageable);
        return new ResponseEntity<>(responses, HttpStatus.OK);
    }

    @GetMapping("/history")
    public ResponseEntity<TransactionHistorydto> getTransactionHistory(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {
        TransactionHistorydto history = transactionService.getTransactionHistory(startDate, endDate);
        return new ResponseEntity<>(history, HttpStatus.OK);
    }
    @GetMapping("/cardBalance/{cardNumber}")
    public ResponseEntity<BigDecimal> getCardBalance(
           @PathVariable String cardNumber) {
        BigDecimal balance = transactionService.getCardBalance(cardNumber);
        return new ResponseEntity<>(balance, HttpStatus.OK);
    }
}
