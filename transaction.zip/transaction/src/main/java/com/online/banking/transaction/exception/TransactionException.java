package com.online.banking.transaction.exception;


public class TransactionException extends RuntimeException {
    public TransactionException(String message) {
        super(message);
    }
}