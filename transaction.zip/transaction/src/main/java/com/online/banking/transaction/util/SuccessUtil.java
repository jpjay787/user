package com.online.banking.transaction.util;

public class SuccessUtil {
    public static final String TRANSACTION_CREATED_SUCCESSFULLY = " created Transaction ";
    public static final String TRANSACTION_UPDATED_SUCCESSFULLY = " updated Transaction ";
    public static final String TRANSACTION_DELETED_SUCCESSFULLY = " deleted Transaction ";
}
