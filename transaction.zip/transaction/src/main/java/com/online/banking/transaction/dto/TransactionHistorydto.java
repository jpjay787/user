package com.online.banking.transaction.dto;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class TransactionHistorydto {
    private BigDecimal totalAmount;

    private int totalTransactions;

    public TransactionHistorydto(BigDecimal totalAmount, int totalTransactions) {
        this.totalAmount = totalAmount;
        this.totalTransactions = totalTransactions;
    }
}