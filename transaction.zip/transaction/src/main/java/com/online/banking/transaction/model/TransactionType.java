package com.online.banking.transaction.model;

public enum TransactionType {
        CREDIT,
        WITHDRAWAL,
        TRANSFER
    }
