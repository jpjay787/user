package com.online.banking.transaction.model;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Entity
@Table(name = "txn")
public class TransactionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    private String cardNumber;
    private BigDecimal amount;
    private BigDecimal balance;
    private LocalDate transactionDate;

}
