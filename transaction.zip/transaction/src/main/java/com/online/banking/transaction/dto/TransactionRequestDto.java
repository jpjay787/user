package com.online.banking.transaction.dto;
import com.online.banking.transaction.model.TransactionType;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransactionRequestDto {
    private Long cardId;
    @NotBlank(message = "amount is mandatory")
    private BigDecimal amount;
  @NotBlank(message = "transactionType is mandatory")
  private TransactionType transactionType;
}
