package com.online.banking.transaction.dto;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class TransactionRequestDto {
    @NotBlank(message = "accountId is mandatory")
    private Long accountId;
    @NotBlank(message = "amount is mandatory")
    private BigDecimal amount;
}
