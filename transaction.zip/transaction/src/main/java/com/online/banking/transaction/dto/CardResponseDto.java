package com.online.banking.transaction.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CardResponseDto {

    private Long id;
    private String cardNumber;
    private boolean isActive;
    private boolean isBlocked;
    private LocalDate issueDate;
    private LocalDate expiryDate;

    private String cardHolderName;
    private int pin;

    private BigDecimal cardBalance;
}
