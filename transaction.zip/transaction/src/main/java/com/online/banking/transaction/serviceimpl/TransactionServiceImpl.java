package com.online.banking.transaction.serviceimpl;

import com.online.banking.transaction.dto.TransactionHistorydto;
import com.online.banking.transaction.dto.TransactionRequestDto;
import com.online.banking.transaction.dto.TransactionResponseDto;
import com.online.banking.transaction.exception.TransactionException;
import com.online.banking.transaction.model.TransactionEntity;
import com.online.banking.transaction.repository.TransactionRepository;
import com.online.banking.transaction.service.TransactionService;
import com.online.banking.transaction.util.ErrorUtil;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final ModelMapper modelMapper;

    @Override
    public TransactionResponseDto createTransaction(TransactionRequestDto transactionRequestDTO) {
        TransactionEntity transaction = modelMapper.map(transactionRequestDTO, TransactionEntity.class);
        transaction.setTransactionDate(LocalDate.now());
        TransactionEntity savedTransaction = transactionRepository.save(transaction);
        return modelMapper.map(savedTransaction, TransactionResponseDto.class);
    }

    @Override
    public TransactionResponseDto getTransactionById(Long transactionId) {
        TransactionEntity transaction = transactionRepository.findByTransactionId(transactionId)
                .orElseThrow(() -> new TransactionException(ErrorUtil.TRANSACTION_NOT_FOUND));
        return modelMapper.map(transaction, TransactionResponseDto.class);
    }

    @Override
    public Page<TransactionResponseDto> getAllTransactions(Pageable pageable) {
        Page<TransactionEntity> transactions = transactionRepository.findAll(pageable);
        return transactions.map(transaction -> modelMapper.map(transaction, TransactionResponseDto.class));
    }

    @Override
    public Page<TransactionResponseDto> getTransactionsByAccountId(Long accountId, Pageable pageable) {
        Page<TransactionEntity> transactions = transactionRepository.findByAccountId(accountId, pageable);
        return transactions.map(transaction -> modelMapper.map(transaction, TransactionResponseDto.class));
    }

    @Override
    public Page<TransactionResponseDto> getTransactionsByDateRange(LocalDate startDate, LocalDate endDate, Pageable pageable) {
        Page<TransactionEntity> transactions = transactionRepository.findByTransactionDateBetween(startDate, endDate, pageable);
        return transactions.map(transaction -> modelMapper.map(transaction, TransactionResponseDto.class));
    }



    @Override
    public TransactionHistorydto getTransactionHistory(LocalDate startDate, LocalDate endDate) {
        List<TransactionEntity> transactions =  transactionRepository.findByTransactionDateBetween(startDate, endDate);
        BigDecimal totalAmount = transactions.stream()
                .map(TransactionEntity::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        return new TransactionHistorydto(totalAmount, transactions.size());
    }
}
