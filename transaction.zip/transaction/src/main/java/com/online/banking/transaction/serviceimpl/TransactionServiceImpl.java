package com.online.banking.transaction.serviceimpl;

import com.online.banking.transaction.dto.CardResponseDto;
//import com.online.banking.cards.exception.CardNotFoundException;
import com.online.banking.transaction.client.CardClient;
import com.online.banking.transaction.dto.TransactionHistorydto;
import com.online.banking.transaction.dto.TransactionRequestDto;
import com.online.banking.transaction.dto.TransactionResponseDto;
import com.online.banking.transaction.exception.CardNotActiveException;
import com.online.banking.transaction.exception.InsufficientFundsException;
import com.online.banking.transaction.exception.TransactionException;
import com.online.banking.transaction.model.TransactionEntity;
import com.online.banking.transaction.model.TransactionType;
import com.online.banking.transaction.repository.TransactionRepository;
import com.online.banking.transaction.service.TransactionService;
import com.online.banking.transaction.util.ErrorUtil;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TransactionServiceImpl implements TransactionService {
    private final TransactionRepository transactionRepository;
    private final ModelMapper modelMapper;
    private final CardClient cardClient;

    @Override
    public TransactionResponseDto createTransaction(TransactionRequestDto transactionRequestDto) {
        // Get card details from Card Service
        CardResponseDto cardResponseDto = cardClient.getCardNumber(transactionRequestDto.getCardNumber());
        if (cardResponseDto == null) {
            throw new RuntimeException("Card number " + transactionRequestDto.getCardNumber() + " not found");
        }

        // Check if card is active
        if (!cardResponseDto.isActive()) {
            throw new CardNotActiveException("Card number " + transactionRequestDto.getCardNumber() + " is not active");
        }

        // Process the transaction based on type
        if (transactionRequestDto.getTransactionType() == TransactionType.WITHDRAWAL) {
            processDebitTransaction(transactionRequestDto, cardResponseDto);
        } else if (transactionRequestDto.getTransactionType() == TransactionType.CREDIT) {
            processCreditTransaction(transactionRequestDto);
        }

        // Update card balance after the transaction
        CardResponseDto updatedCard = cardClient.getCardNumber(transactionRequestDto.getCardNumber());

        // Map and save transaction
        TransactionEntity transactionEntity = modelMapper.map(transactionRequestDto, TransactionEntity.class);
        transactionEntity.setTransactionDate(LocalDate.now());
        transactionEntity.setBalance(updatedCard.getCardBalance());
        TransactionEntity savedTransaction = transactionRepository.save(transactionEntity);

        // Return transaction response
        return modelMapper.map(savedTransaction, TransactionResponseDto.class);
    }

    private void processDebitTransaction(TransactionRequestDto transactionRequestDto, CardResponseDto cardResponseDto) {
        // Ensure sufficient funds
        if (cardResponseDto.getCardBalance().compareTo(transactionRequestDto.getAmount()) < 0) {
            throw new InsufficientFundsException("Insufficient funds on card " + transactionRequestDto.getCardNumber());
        }

        // Debit amount via Card Service
        cardClient.debitAmount(transactionRequestDto);
    }

    private void processCreditTransaction(TransactionRequestDto transactionRequestDto) {
        // Credit amount via Card Service
        cardClient.creditAmount(transactionRequestDto);
    }

    @Override
    public TransactionResponseDto getTransactionById(Long transactionId) {
        TransactionEntity transaction = transactionRepository.findByTransactionId(transactionId)
                .orElseThrow(() -> new TransactionException(ErrorUtil.TRANSACTION_NOT_FOUND));
        return modelMapper.map(transaction, TransactionResponseDto.class);
    }

    @Override
    public Page<TransactionResponseDto> getAllTransactions(Pageable pageable) {
        Page<TransactionEntity> transactions = transactionRepository.findAll(pageable);
        return transactions.map(transaction -> modelMapper.map(transaction, TransactionResponseDto.class));
    }

    @Override
    public Page<TransactionResponseDto> getTransactionsByCardNumber(String cardNumber, Pageable pageable) {
        Page<TransactionEntity> transactions = transactionRepository.findByCardNumber(cardNumber, pageable);
        return transactions.map(transaction -> modelMapper.map(transaction, TransactionResponseDto.class));
    }

    @Override
    public Page<TransactionResponseDto> getTransactionsByDateRange(LocalDate startDate, LocalDate endDate, Pageable pageable) {
        Page<TransactionEntity> transactions = transactionRepository.findByTransactionDateBetween(startDate, endDate, pageable);
        return transactions.map(transaction -> modelMapper.map(transaction, TransactionResponseDto.class));
    }

    @Override
    public TransactionHistorydto getTransactionHistory(LocalDate startDate, LocalDate endDate) {
        List<TransactionEntity> transactions = transactionRepository.findByTransactionDateBetween(startDate, endDate);
        BigDecimal totalAmount = transactions.stream()
                .map(TransactionEntity::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        return new TransactionHistorydto(totalAmount, transactions.size());
    }

    @Override
    public BigDecimal getCardBalance(String cardNumber) {
        return cardClient.getCardNumber(cardNumber).getCardBalance();
    }
}
