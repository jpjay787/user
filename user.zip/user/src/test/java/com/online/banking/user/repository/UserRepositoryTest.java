package com.online.banking.user.repository;

import com.online.banking.model.Gender;
import com.online.banking.model.Role;
import com.online.banking.model.User;
import com.online.banking.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;


import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    private User user;

    @BeforeEach
    public void setup() {
        user = User.builder()
                .name("John Doe")
                .email("john.doe@example.com")
                .password("password123")
                .phoneNumber("1234567890")
                .gender(Gender.MALE)
                .login(false)
                .blocked(false)
                .failedLoginAttempts(0)
                .role(Role.USER)
                .build();

        // Save user to the in-memory database
        userRepository.save(user);
    }

    @Test
    public void testFindByEmail() {
        // Test the findByEmail method
        User foundUser = userRepository.findByEmail("john.doe@example.com");

        // Assertions
        assertThat(foundUser).isNotNull();
        assertThat(foundUser.getEmail()).isEqualTo("john.doe@example.com");
        assertThat(foundUser.getName()).isEqualTo("John Doe");
    }

    @Test
    public void testFindByEmail_NotFound() {
        // Test when email doesn't exist
        User foundUser = userRepository.findByEmail("non.existent@example.com");

        // Assertion: No user should be found
        assertThat(foundUser).isNull();
    }

    @Test
    public void testSaveUser() {
        // Save a new user
        User newUser = User.builder()
                .name("Jane Doe")
                .email("jane.doe@example.com")
                .password("password456")
                .phoneNumber("0987654321")
                .gender(Gender.FEMALE)
                .login(false)
                .blocked(false)
                .failedLoginAttempts(0)
                .role(Role.USER)
                .build();

        User savedUser = userRepository.save(newUser);

        // Assertions
        assertThat(savedUser).isNotNull();
        assertThat(savedUser.getId()).isNotNull();
        assertThat(savedUser.getName()).isEqualTo("Jane Doe");
        assertThat(savedUser.getEmail()).isEqualTo("jane.doe@example.com");
    }

    @Test
    public void testDeleteUser() {
        // Delete the user
        userRepository.delete(user);

        // Check if the user is deleted
        Optional<User> deletedUser = userRepository.findById(user.getId());

        // Assertions
        assertThat(deletedUser).isEmpty();
    }
}
