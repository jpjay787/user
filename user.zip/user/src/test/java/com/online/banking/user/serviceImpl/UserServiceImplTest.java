package com.online.banking.user.serviceImpl;

import com.online.banking.dto.UserRequestDto;
import com.online.banking.dto.UserResponseDto;
import com.online.banking.exception.AccountBlockedException;
import com.online.banking.exception.InvalidCredentialsException;
import com.online.banking.exception.UserNotFoundException;
import com.online.banking.model.Role;
import com.online.banking.model.User;
import com.online.banking.repository.UserRepository;
import com.online.banking.serviceimpl.UserServiceImpl;
import com.online.banking.util.ConstantUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageImpl;

import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private UserServiceImpl userService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testRegisterUser_Success() {
        UserRequestDto userRequestDto = new UserRequestDto();
        userRequestDto.setEmail("test@example.com");
        User user = new User();
        User savedUser = new User();
        UserResponseDto userResponseDto = new UserResponseDto();

        when(userRepository.findByEmail(userRequestDto.getEmail())).thenReturn(null);
        when(modelMapper.map(userRequestDto, User.class)).thenReturn(user);
        when(userRepository.save(user)).thenReturn(savedUser);
        when(modelMapper.map(savedUser, UserResponseDto.class)).thenReturn(userResponseDto);

        UserResponseDto response = userService.registerUser(userRequestDto);

        assertNotNull(response);
        verify(userRepository).save(user);
    }

    @Test
    public void testRegisterUser_UserAlreadyExists() {
        UserRequestDto userRequestDto = new UserRequestDto();
        userRequestDto.setEmail("test@example.com");
        User existingUser = new User();

        when(userRepository.findByEmail(userRequestDto.getEmail())).thenReturn(existingUser);

        assertThrows(UserNotFoundException.class, () -> userService.registerUser(userRequestDto));
    }

    @Test
    public void testLoginUser_Success() {
        String email = "test@example.com";
        String password = "password";
        User user = new User();
        user.setEmail(email);
        user.setPassword(password);
        user.setLogin(false);
        UserResponseDto userResponseDto = new UserResponseDto();

        when(userRepository.findByEmail(email)).thenReturn(user);
        when(modelMapper.map(user, UserResponseDto.class)).thenReturn(userResponseDto);

        UserResponseDto response = userService.loginUser(email, password);

        assertNotNull(response);
        assertTrue(user.isLogin());
        verify(userRepository).save(user);
    }

    @Test
    public void testLoginUser_InvalidPassword() {
        String email = "test@example.com";
        String password = "wrongpassword";
        User user = new User();
        user.setEmail(email);
        user.setPassword("password");
        user.setLogin(false);

        when(userRepository.findByEmail(email)).thenReturn(user);

        assertThrows(InvalidCredentialsException.class, () -> userService.loginUser(email, password));
        verify(userRepository).save(user);
    }

    @Test
    public void testLoginUser_AccountBlocked() {
        String email = "test@example.com";
        String password = "password";
        User user = new User();
        user.setEmail(email);
        user.setPassword(password);
        user.setLogin(false);
        user.setBlocked(true);

        when(userRepository.findByEmail(email)).thenReturn(user);

        assertThrows(AccountBlockedException.class, () -> userService.loginUser(email, password));
    }

    @Test
    public void testLogoutUser_Success() {
        String email = "test@example.com";
        User user = new User();
        user.setEmail(email);
        user.setLogin(true);

        when(userRepository.findByEmail(email)).thenReturn(user);

        String response = userService.logoutUser(email);

        assertEquals(ConstantUtil.LOGOUT_SUCCESSFUL, response);
        assertFalse(user.isLogin());
        verify(userRepository).save(user);
    }

    @Test
    public void testForgotPassword() {
        String email = "test@example.com";
        User user = new User();
        user.setEmail(email);

        when(userRepository.findByEmail(email)).thenReturn(user);

        String response = userService.forgotPassword(email);

        assertEquals("http://localhost:8080/api/users/change-password?email=" + email, response);
    }

    @Test
    public void testChangePassword_Success() {
        String email = "test@example.com";
        String newPassword = "newpassword";
        String confirmPassword = "newpassword";
        User user = new User();
        user.setEmail(email);

        when(userRepository.findByEmail(email)).thenReturn(user);

        String response = userService.changePassword(email, newPassword, confirmPassword);

        assertEquals(ConstantUtil.PASSWORD_CHANGED_SUCCESS, response);
        assertEquals(newPassword, user.getPassword());
        verify(userRepository).save(user);
    }

    @Test
    public void testUnblockUserAccount_Success() {
        String email = "test@example.com";
        String adminEmail = "admin@example.com";
        User user = new User();
        user.setEmail(email);
        user.setBlocked(true);
        User adminUser = new User();
        adminUser.setEmail(adminEmail);
        adminUser.setRole(Role.ADMIN);

        when(userRepository.findByEmail(adminEmail)).thenReturn(adminUser);
        when(userRepository.findByEmail(email)).thenReturn(user);

        String response = userService.unblockUserAccount(email, adminEmail);

        assertEquals(ConstantUtil.USER_ACCOUNT_UNBLOCKED_SUCCESS, response);
        assertFalse(user.isBlocked());
        verify(userRepository).save(user);
    }

    @Test
    public void testSearchUsersByEmail() {
        String email = "test@example.com";
        User user = new User();
        user.setEmail(email);
        UserResponseDto userResponseDto = new UserResponseDto();
        Page<User> users = new PageImpl<>(Collections.singletonList(user));

        when(userRepository.findByEmailContainingIgnoreCase(email, Pageable.unpaged())).thenReturn(users);
        when(modelMapper.map(user, UserResponseDto.class)).thenReturn(userResponseDto);

        Page<UserResponseDto> response = userService.searchUsersByEmail(email, Pageable.unpaged());

        assertNotNull(response);
        assertEquals(1, response.getTotalElements());
    }

    @Test
    public void testSearchUsersByEmail_EmptyResult() {
        String email = "test@example.com";
        when(userRepository.findByEmailContainingIgnoreCase(email, Pageable.unpaged())).thenReturn(Page.empty());

        assertThrows(UserNotFoundException.class, () -> userService.searchUsersByEmail(email, Pageable.unpaged()));
    }
}
