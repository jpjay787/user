package com.online.banking.user.controller;

import com.online.banking.controller.UserController;
import com.online.banking.dto.*;
import com.online.banking.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    private UserRequestDto userRequestDto;
    private LoginRequestDto loginRequestDto;
    private EmailRequestDto emailRequestDto;
    private PasswordChangeRequestDto passwordChangeRequestDto;
    private UnblockRequestDto unblockRequestDto;
    private UserResponseDto userResponseDto;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        userRequestDto = new UserRequestDto();
        userRequestDto.setEmail("test@example.com");
        userRequestDto.setPassword("password");

        loginRequestDto = new LoginRequestDto();
        loginRequestDto.setEmail("test@example.com");
        loginRequestDto.setPassword("password");

        emailRequestDto = new EmailRequestDto();
        emailRequestDto.setEmail("test@example.com");

        passwordChangeRequestDto = new PasswordChangeRequestDto();
        passwordChangeRequestDto.setEmail("test@example.com");
        passwordChangeRequestDto.setNewPassword("newpassword");
        passwordChangeRequestDto.setConfirmPassword("newpassword");

        unblockRequestDto = new UnblockRequestDto();
        unblockRequestDto.setEmail("test@example.com");
        unblockRequestDto.setAdminEmail("admin@example.com");

        userResponseDto = new UserResponseDto();
        userResponseDto.setEmail("test@example.com");
    }

    @Test
    void testRegisterUser() {
        when(userService.registerUser(any(UserRequestDto.class))).thenReturn(userResponseDto);

        ResponseEntity<UserResponseDto> response = userController.registerUser(userRequestDto);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userResponseDto, response.getBody());
        verify(userService, times(1)).registerUser(any(UserRequestDto.class));
    }

    @Test
    void testLoginUser() {
        when(userService.loginUser(anyString(), anyString())).thenReturn(userResponseDto);

        ResponseEntity<UserResponseDto> response = userController.loginUser(loginRequestDto);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userResponseDto, response.getBody());
        verify(userService, times(1)).loginUser(anyString(), anyString());
    }

    @Test
    void testLogoutUser() {
        when(userService.logoutUser(anyString())).thenReturn("User logged out successfully");

        ResponseEntity<String> response = userController.logoutUser(emailRequestDto);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("User logged out successfully", response.getBody());
        verify(userService, times(1)).logoutUser(anyString());
    }

    @Test
    void testForgotPassword() {
        when(userService.forgotPassword(anyString())).thenReturn("Password reset link sent to your email");

        ResponseEntity<String> response = userController.forgotPassword(emailRequestDto);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Password reset link sent to your email", response.getBody());
        verify(userService, times(1)).forgotPassword(anyString());
    }

    @Test
    void testChangePassword() {
        when(userService.changePassword(anyString(), anyString(), anyString())).thenReturn("Password changed successfully");

        ResponseEntity<String> response = userController.changePassword(passwordChangeRequestDto);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Password changed successfully", response.getBody());
        verify(userService, times(1)).changePassword(anyString(), anyString(), anyString());
    }

    @Test
    void testSearchUsersByEmail() {
        Page<UserResponseDto> page = new PageImpl<>(Collections.singletonList(userResponseDto));
        when(userService.searchUsersByEmail(anyString(), any(PageRequest.class))).thenReturn(page);

        ResponseEntity<Page<UserResponseDto>> response = userController.searchUsersByEmail("test@example.com", PageRequest.of(0, 10));

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().getTotalElements());
        assertEquals(userResponseDto, response.getBody().getContent().get(0));
        verify(userService, times(1)).searchUsersByEmail(anyString(), any(PageRequest.class));
    }

    @Test
    void testUnblockUserAccount() {
        when(userService.unblockUserAccount(anyString(), anyString())).thenReturn("User account unblocked");

        ResponseEntity<String> response = userController.unblockUserAccount(unblockRequestDto);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("User account unblocked", response.getBody());
        verify(userService, times(1)).unblockUserAccount(anyString(), anyString());
    }
}
