CREATE TABLE user_online_bank (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    gender VARCHAR(20) NOT NULL,
    login BOOLEAN NOT NULL,
    blocked BOOLEAN NOT NULL,
    failed_login_attempts INT NOT NULL,
    role VARCHAR(25) NOT NULL
);

