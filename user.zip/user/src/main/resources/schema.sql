CREATE TABLE USER_ONLINE_BANK (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20),
    name VARCHAR(255),
    gender VARCHAR(10),
    login VARCHAR(255),
    blocked BOOLEAN,
    failed_login_attempts INT,
    role VARCHAR(50)
);
