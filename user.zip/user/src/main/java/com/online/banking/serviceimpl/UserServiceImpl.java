package com.online.banking.serviceimpl;

import com.online.banking.account.dto.AccountRequestDTO;
import com.online.banking.account.dto.AccountResponseDTO;
import com.online.banking.cards.dto.CardRequestDto;
import com.online.banking.cards.dto.CardResponseDto;
import com.online.banking.client.AccountClient;
import com.online.banking.client.CardClient;
import com.online.banking.dto.*;
import com.online.banking.exception.AccountBlockedException;
import com.online.banking.exception.InvalidCredentialsException;
import com.online.banking.exception.UserNotFoundException;
import com.online.banking.model.Role;
import com.online.banking.model.User;
import com.online.banking.repository.UserRepository;
import com.online.banking.service.UserService;
import com.online.banking.util.ConstantUtil;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private static final int MAX_FAILED_ATTEMPTS = 3;
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final AccountClient accountClient;
    private final CardClient cardClient;

    @Override
    public UserResponseDto registerUser(UserRequestDto userRequestDto) {
        User existingUser = userRepository.findByEmail(userRequestDto.getEmail());
        if (existingUser != null) {
            throw new UserNotFoundException(ConstantUtil.USER_ALREADY_REGISTERED);
        }

        User newUser = modelMapper.map(userRequestDto, User.class);
        newUser.setLogin(false);
        newUser.setBlocked(false);
        newUser.setFailedLoginAttempts(0);

        User savedUser = userRepository.save(newUser);
        if (!createAccountCard(savedUser)) {
            throw new RuntimeException("cant create Account and card");
        }

        return modelMapper.map(savedUser, UserResponseDto.class);
    }
public boolean createAccountCard(User user){
    AccountRequestDTO accountRequestDTO = new AccountRequestDTO();
    accountRequestDTO.setAccountHolderName(user.getName());
    accountRequestDTO.setUserId(user.getId());
    AccountResponseDTO accountResponseDTO = accountClient.createAccount((accountRequestDTO));
    if(accountResponseDTO==null){
        return false;
    }
    CardRequestDto cardRequestDto = new CardRequestDto();
    cardRequestDto.setAccountId(accountResponseDTO.getId());
    cardRequestDto.setCardHolderName(user.getName());
    cardRequestDto.setBalance(BigDecimal.valueOf(accountResponseDTO.getBalance()));
    CardResponseDto cardResponseDTO=cardClient.issueCard(cardRequestDto);
    return cardResponseDTO != null;
}

    @Override
    public UserResponseDto loginUser(String email, String password) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new UserNotFoundException(ConstantUtil.USER_NOT_FOUND);
        }

        if (user.isBlocked()) {
            throw new AccountBlockedException(ConstantUtil.ACCOUNT_BLOCKED);
        }
        if (user.isLogin()) {
            throw new UserNotFoundException(ConstantUtil.USER_LOGGEDIN_ALREADY);
        }

        if (!user.getPassword().equals(password)) {
            user.setFailedLoginAttempts(user.getFailedLoginAttempts() + 1);
            if (user.getFailedLoginAttempts() >= MAX_FAILED_ATTEMPTS) {
                user.setBlocked(true);
                userRepository.save(user);
                throw new AccountBlockedException(ConstantUtil.ACCOUNT_BLOCKED);
            }
            userRepository.save(user);
            throw new InvalidCredentialsException(ConstantUtil.INVALID_CREDENTIALS);
        }

        user.setFailedLoginAttempts(0);
        user.setLogin(true);
        userRepository.save(user);

        return modelMapper.map(user, UserResponseDto.class);
    }

    @Override
    public String logoutUser(String email) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new UserNotFoundException(ConstantUtil.USER_NOT_FOUND);
        }

        if (!user.isLogin()) {
            throw new UserNotFoundException(ConstantUtil.USER_NOT_LOGGED_IN);
        }

        user.setLogin(false);
        userRepository.save(user);

        return ConstantUtil.LOGOUT_SUCCESSFUL;
    }

    @Override
    public String forgotPassword(String email) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new UserNotFoundException(ConstantUtil.USER_NOT_FOUND);
        }

        return "http://localhost:8080/api/users/change-password?email=" + email;
    }

    @Override
    public String changePassword(String email, String newPassword, String confirmPassword) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new UserNotFoundException(ConstantUtil.USER_NOT_FOUND);
        }

        if (!newPassword.equals(confirmPassword)) {
            throw new UserNotFoundException(ConstantUtil.PASSWORD_NOT_MATCHED);
        }
        user.setPassword(newPassword);
        userRepository.save(user);
        return ConstantUtil.PASSWORD_CHANGED_SUCCESS;
    }

    @Override
    public String unblockUserAccount(String email, String adminEmail) {
        User adminUser = userRepository.findByEmail(adminEmail);
        if (adminUser == null) {
            throw new UserNotFoundException(ConstantUtil.ADMIN_NOT_FOUND);
        }

        if (!Role.ADMIN.equals(adminUser.getRole())) {
            throw new UserNotFoundException(ConstantUtil.ONLY_ADMIN_CAN_UNBLOCK);
        }

        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new UserNotFoundException(ConstantUtil.USER_NOT_FOUND);
        }

        if (!user.isBlocked()) {
            throw new UserNotFoundException(ConstantUtil.USER_NOT_BLOCKED);
        }

        user.setBlocked(false);
        user.setFailedLoginAttempts(0);
        userRepository.save(user);

        return ConstantUtil.USER_ACCOUNT_UNBLOCKED_SUCCESS;
    }

    @Override
    public Page<UserResponseDto> searchUsersByEmail(String email, Pageable pageable) {
        Page<User> users = userRepository.findByEmailContainingIgnoreCase(email, pageable);
        if (users.isEmpty()) {
            throw new UserNotFoundException(ConstantUtil.USER_NOT_FOUND);
        }
        return users.map(user -> modelMapper.map(user, UserResponseDto.class));
    }
    @Override
    public UserResponseDto findById(Long id) {
        Optional<User> user = userRepository.findById(id);

        if (!user.isPresent()) {
            throw new UserNotFoundException(ConstantUtil.USER_NOT_FOUND);
        }

        return modelMapper.map(user.get(), UserResponseDto.class);
    }

}
