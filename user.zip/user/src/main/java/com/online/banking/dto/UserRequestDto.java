package com.online.banking.dto;

import com.online.banking.model.Gender;
import com.online.banking.model.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserRequestDto {
    private String message;
    @NotBlank(message = "Name is mandatory")
    private String name;

    @NotBlank(message = "email is mandatory")
    private String email;

    @NotBlank(message = "Password is mandatory")
    @Size(min=8, message ="Minimum 8 characters")
    private String password;

    @NotBlank(message = "Phone number is mandatory")
    @Size(min=10, message ="Minimum 10 characters")
    private String phoneNumber;

    @NotNull(message = "Gender is mandatory")
    private Gender gender;

    @NotNull(message = "Role is mandatory")
    private Role role;

}
