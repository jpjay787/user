package com.online.banking.service;

import com.online.banking.dto.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserService {
    UserResponseDto registerUser(UserRequestDto userRequestDto);
    UserResponseDto loginUser(String email, String password);
    String logoutUser(String email);
    String forgotPassword(String email);
    String changePassword(String email, String newPassword, String confirmPassword);
    String unblockUserAccount(String email, String adminEmail);
    Page<UserResponseDto> searchUsersByEmail(String email, Pageable pageable);
}
