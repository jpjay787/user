package com.online.banking.service;

import com.online.banking.dto.UserRequestDto;
import com.online.banking.dto.UserResponseDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


public interface UserService {
    UserResponseDto registerUser(UserRequestDto userRequestDto);
    String forgotPassword(String email);
    String changePassword(String email, String newPassword, String confirmPassword);
    UserResponseDto loginUser(String email, String password);
    String logoutUser(String email);
    String unblockUserAccount(String email, String adminEmail);
    Page<UserResponseDto> searchUsersByEmail(String email, Pageable pageable);
}
