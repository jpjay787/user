package com.online.banking.dto;

import com.online.banking.model.Gender;
import com.online.banking.model.Role;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserResponseDto {
    private long id;
    private String name;
    private String email;
    private String phoneNumber;
    private Gender gender;
    private Role role;
    private String message;


}

