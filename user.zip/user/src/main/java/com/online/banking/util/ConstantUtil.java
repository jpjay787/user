package com.online.banking.util;

public class ConstantUtil {
    public static final String REGISTRATION_SUCCESSFUL_MESSAGE = "User registration is completed";
    public static final String USER_ALREADY_REGISTERED = "User is already registered with this email";
    public static final String USER_NOT_FOUND = "User not found";
    public static final String PASSWORD_NOT_MATCHED = "Current password does not match";
    public static final String PASSWORD_CHANGED_SUCCESS = "Password has been successfully changed";
    public static final String LOGIN_SUCCESSFUL = "Login successful";
    public static final String LOGOUT_SUCCESSFUL = "Logout successful";
    public static final String USER_NOT_LOGGED_IN = "User not loggedin";
    public static final String INVALID_CREDENTIALS = "Invalid email or password";
    public static final String USER_LOGGEDIN_ALREADY = "User is logged in already";
    public static final String USER_ACCOUNT_UNBLOCKED_SUCCESS = "User account has been successfully unblocked";
    public static final String USER_NOT_BLOCKED = "User account is not blocked";
    public static final String ACCOUNT_BLOCKED = "Your account has been blocked due to multiple failed login attempts.";
    public static final String USER_FOUND_SUCCESS = "User(s) found successfully.";
    public static final String ADMIN_NOT_FOUND = "Please Enter Admin's email";
    public static final String ONLY_ADMIN_CAN_UNBLOCK = "Admin only unblock";
}

