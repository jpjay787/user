package com.online.banking.client;

import com.online.banking.account.dto.AccountRequestDTO;
import com.online.banking.account.dto.AccountResponseDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


@Component
@RequiredArgsConstructor
public class AccountClient {

    private final RestTemplate restTemplate;
    @Value("${service.createaccount.url}")
    private String accountServiceUrl;
    public AccountResponseDTO createAccount(AccountRequestDTO accountRequestDTO){
        ResponseEntity<AccountResponseDTO> response=restTemplate.postForEntity(accountServiceUrl, accountRequestDTO, AccountResponseDTO.class);
        return response.getBody();
    }

}
