package com.online.banking.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // Lombok annotation that generates all the boilerplate code that is normally associated with simple POJOs
@Builder //way to create and configure an instance of a class by specifying its properties
@AllArgsConstructor
@NoArgsConstructor //Lombok annotations that automatically generate a constructor with all the fields (all arguments)
@Entity //class is an entity and is mapped to a database table
@Table(name = "user_online_bank")
public class User {

    @Id //primary key of the entity
    @GeneratedValue(strategy = GenerationType.IDENTITY) //auto-increment field.
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String phoneNumber;

    @Enumerated(EnumType.STRING) // This specifies that the enum should be stored as a string in the database
    @Column(nullable = false)
    private Gender gender;

    @Column(nullable = false)
    private boolean login;

    @Column(nullable = false)
    private boolean blocked;

    @Column(nullable = false)
    private int failedLoginAttempts;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;
}
