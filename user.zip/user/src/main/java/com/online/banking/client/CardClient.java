package com.online.banking.client;

import com.online.banking.account.dto.AccountRequestDTO;
import com.online.banking.account.dto.AccountResponseDTO;
import com.online.banking.cards.dto.CardRequestDto;
import com.online.banking.cards.dto.CardResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class CardClient {

        private final RestTemplate restTemplate;
        @Value("${service.createcard.url}")
        private String cardServiceUrl;
        public CardResponseDto issueCard(CardRequestDto cardRequestDto){
            ResponseEntity<CardResponseDto> response=restTemplate.postForEntity(cardServiceUrl, cardRequestDto, CardResponseDto.class);
            return response.getBody();
        }

    }


