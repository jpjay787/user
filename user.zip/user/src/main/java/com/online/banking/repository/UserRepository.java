package com.online.banking.repository;

import com.online.banking.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email); // Returns a User, or null if not found
    Page<User> findByEmailContainingIgnoreCase(String email, Pageable pageable);
}
