package com.online.banking.controller;

import com.online.banking.dto.*;
import com.online.banking.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {
    private final UserService userService;

    @PostMapping("/register")
    public ResponseEntity<UserResponseDto> registerUser(@Valid @RequestBody UserRequestDto userRequestDto) {
        UserResponseDto responseDto = userService.registerUser(userRequestDto);
        return ResponseEntity.ok(responseDto);
    }

    @PostMapping("/login")
    public ResponseEntity<UserResponseDto> loginUser(@Valid @RequestBody LoginRequestDto userRequestDto) {
        UserResponseDto responseDto = userService.loginUser(userRequestDto.getEmail(), userRequestDto.getPassword());
        return ResponseEntity.ok(responseDto);
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logoutUser(@Valid @RequestBody EmailRequestDto userRequestDto) {
        String responseMessage = userService.logoutUser(userRequestDto.getEmail());
        return ResponseEntity.ok(responseMessage);
    }
    @GetMapping("/search/{id}")
    public ResponseEntity<UserResponseDto> findbyid(@PathVariable Long id){
        UserResponseDto user=userService.findById(id);
        return ResponseEntity.ok(user);
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@Valid @RequestBody EmailRequestDto userRequestDto) {
        String changePasswordLink = userService.forgotPassword(userRequestDto.getEmail());
        return ResponseEntity.ok(changePasswordLink);
    }

    @PostMapping("/change-password")
    public ResponseEntity<String> changePassword(@Valid @RequestBody PasswordChangeRequestDto userRequestDto) {
        String result = userService.changePassword(
                userRequestDto.getEmail(),
                userRequestDto.getNewPassword(),
                userRequestDto.getConfirmPassword());
        return ResponseEntity.ok(result);
    }

    @GetMapping("/search/email")
    public ResponseEntity<Page<UserResponseDto>> searchUsersByEmail(
            @RequestParam String email,
            @PageableDefault(size = 10, sort = "email") Pageable pageable) {
        return ResponseEntity.ok(userService.searchUsersByEmail(email, pageable));
    }

    @PatchMapping("/unblock")
    public ResponseEntity<String> unblockUserAccount(
            @Valid @RequestBody UnblockRequestDto unblockRequestDto) {
        String responseMessage = userService.unblockUserAccount(
                unblockRequestDto.getEmail(),
                unblockRequestDto.getAdminEmail());
        return ResponseEntity.ok(responseMessage);
    }

}
