package com.online.banking.controller;

import com.online.banking.dto.*;
import com.online.banking.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // is a combination of @Controller and @ResponseBody. It marks the class as a Spring MVC controller
@RequestMapping("/api/users") //This annotation is used to map web requests to specific handler classes
@RequiredArgsConstructor //This is a Lombok annotation that generates a constructor with 1 parameter for each field that requires special handling
public class UserController {

    private final UserService userService;
//These annotations are specific to HTTP methods (POST, PUT, GET, etc.)
    @PostMapping("/register")
    //@RequestBody- This annotation is used to map the HTTP request body to a domain object in controller methods.
    public ResponseEntity<UserResponseDto> registerUser(@Valid @RequestBody UserRequestDto userRequestDto) {
        UserResponseDto responseDto = userService.registerUser(userRequestDto);
        //ResponseEntity - wrapper around an HTTP response that allows you to customize the status code, headers, and body of the response.
        return ResponseEntity.ok(responseDto);
    }

    @PostMapping("/login")
    public ResponseEntity<UserResponseDto> loginUser(@Valid @RequestBody LoginRequestDto userRequestDto) {
        UserResponseDto responseDto = userService.loginUser(userRequestDto.getEmail(), userRequestDto.getPassword());
        return ResponseEntity.ok(responseDto);
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logoutUser(@Valid @RequestBody EmailRequestDto userRequestDto) {
        String responseMessage = userService.logoutUser(userRequestDto.getEmail());
        return ResponseEntity.ok(responseMessage);
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@Valid @RequestBody EmailRequestDto userRequestDto) {
        String changePasswordLink = userService.forgotPassword(userRequestDto.getEmail());
        return ResponseEntity.ok(changePasswordLink);
    }

    @PostMapping("/change-password")
    public ResponseEntity<String> changePassword(@Valid @RequestBody PasswordChangeRequestDto userRequestDto) {
        String result = userService.changePassword(
                userRequestDto.getEmail(),
                userRequestDto.getNewPassword(),
                userRequestDto.getConfirmPassword());
        return ResponseEntity.ok(result);
    }

    @GetMapping("/search/email")
    public ResponseEntity<Page<UserResponseDto>> searchUsersByEmail(
            @RequestParam String email,
            @PageableDefault(size = 10, sort = "email") Pageable pageable) {
        return ResponseEntity.ok(userService.searchUsersByEmail(email, pageable));
    }

    @PatchMapping("/unblock")
    public ResponseEntity<String> unblockUserAccount(
            @Valid @RequestBody UnblockRequestDto unblockRequestDto) {
        String responseMessage = userService.unblockUserAccount(
                unblockRequestDto.getEmail(),
                unblockRequestDto.getAdminEmail());
        return ResponseEntity.ok(responseMessage);
    }

}
