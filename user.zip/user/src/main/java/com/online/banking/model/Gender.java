package com.online.banking.model;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
