package com.online.banking.model;

public enum Role {
    ADMIN,
    USER
}
