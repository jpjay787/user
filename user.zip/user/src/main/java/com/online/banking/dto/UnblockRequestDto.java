package com.online.banking.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UnblockRequestDto {
    @NotBlank
    @Email
    private String email;

    @NotBlank
    @Email
    private String adminEmail;
}