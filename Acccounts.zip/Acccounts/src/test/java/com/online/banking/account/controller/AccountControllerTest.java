package com.online.banking.account.controller;

import com.online.banking.account.dto.AccountRequestDTO;
import com.online.banking.account.dto.AccountResponseDTO;
import com.online.banking.account.model.AccountStatus;
import com.online.banking.account.service.AccountService;
import com.online.banking.account.serviceimpl.AccountServiceImpl;
import com.online.banking.account.util.SuccessMessageUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.Collections;import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AccountControllerTest {
   // @Autowired
   private MockMvc mockMvc;
    @Mock
    private AccountServiceImpl accountService;
    @InjectMocks
    private AccountController accountController;
    private AccountRequestDTO accountRequestDTO;
    private AccountResponseDTO accountResponseDTO;
    @BeforeEach
    void setUp() {
        accountResponseDTO = new AccountResponseDTO(1L,
                "1234567890",
                "Savings",
                AccountStatus.ACTIVE,
                1L,
                1000.0,
                "Success");
        accountRequestDTO = new AccountRequestDTO();
    }

    @Test
     void testCreateAccount(){
    AccountRequestDTO accountRequestDTO=new AccountRequestDTO();
    accountRequestDTO.setAccountNumber("1234567890");
    accountRequestDTO.setUserId(1L);
    accountRequestDTO.setAccountStatus(String.valueOf(AccountStatus.ACTIVE));
    accountRequestDTO.setAccountType("SAVINGS");
    accountRequestDTO.setBalance(100);
when(accountService.createAccount(accountRequestDTO)).thenReturn(accountResponseDTO);
    ResponseEntity<String> response = accountController.createAccount(accountRequestDTO);
    assertEquals(SuccessMessageUtil.ACCOUNT_CREATED,response.getBody());
    }
        @Test
        void testDeleteAccount() throws Exception {
            mockMvc.perform(delete("/api/accounts/{accountId}", 1L))
                    .andExpect(status().isOk())
                    .andExpect(content().string(SuccessMessageUtil.ACCOUNT_DELETED));
        }

        @Test
        void testChangeAccountType() throws Exception {
            when(accountService.changeAccountType(anyLong(), anyString())).thenReturn(accountResponseDTO);

            mockMvc.perform(put("/api/accounts/{accountId}/type", 1L)
                            .contentType(MediaType.TEXT_PLAIN)
                            .content("Current"))
                    .andExpect(status().isOk())
                    .andExpect(content().string(SuccessMessageUtil.ACCOUNT_TYPE_CHANGED));
        }

        @Test
        void testActivateAccountIfEligible() throws Exception {
            when(accountService.activateAccountIfEligible(anyLong())).thenReturn("Activation process completed");

            mockMvc.perform(put("/api/accounts/{accountId}/activate", 1L))
                    .andExpect(status().isOk())
                    .andExpect(content().string("Activation process completed"));
        }

        @Test
        void testDeactivateAccount() throws Exception {
            when(accountService.deactivateAccount(anyLong())).thenReturn(SuccessMessageUtil.ACCOUNT_DEACTIVATED);

            mockMvc.perform(put("/api/accounts/{accountId}/deactivate", 1L))
                    .andExpect(status().isOk())
                    .andExpect(content().string(SuccessMessageUtil.ACCOUNT_DEACTIVATED));
        }

        @Test
        void testGetAllAccounts() throws Exception {
            Page<AccountResponseDTO> accountPage = new PageImpl<>(Collections.singletonList(accountResponseDTO));
            when(accountService.getAllAccounts(any(Pageable.class))).thenReturn(accountPage);

            mockMvc.perform(get("/api/accounts")
                            .param("page", "0")
                            .param("size", "10")
                            .param("sortBy", "id")
                            .param("sortDir", "asc"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.content", hasSize(1)))
                    .andExpect(jsonPath("$.content[0].accountNumber", is("1234567890")));
        }

        @Test
        void testGetAccountDetails() throws Exception {
            when(accountService.getAccountDetails(anyLong())).thenReturn(accountResponseDTO);

            mockMvc.perform(get("/api/accounts/{accountId}", 1L))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.accountNumber", is("1234567890")));
        }

        @Test
        void testSearchAccountsByNumber() throws Exception {
            when(accountService.searchAccountsByNumber(anyString())).thenReturn(accountResponseDTO);
            mockMvc.perform(get("/api/accounts/searchbyaccno")
                            .param("accountNumber", "1234567890"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.accountNumber", is("1234567890")));
        }
}
