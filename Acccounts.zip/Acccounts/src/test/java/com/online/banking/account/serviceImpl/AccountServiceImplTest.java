package com.online.banking.account.serviceImpl;

import com.online.banking.account.dto.AccountRequestDTO;
import com.online.banking.account.dto.AccountResponseDTO;
import com.online.banking.account.exception.AccountNotFoundException;
import com.online.banking.account.model.AccountEntity;
import com.online.banking.account.model.AccountStatus;
import com.online.banking.account.repository.AccountRepository;
import com.online.banking.account.serviceimpl.AccountServiceImpl;
import com.online.banking.account.util.SuccessMessageUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AccountServiceImplTest {

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private AccountServiceImpl accountService;

    @Captor
    private ArgumentCaptor<AccountEntity> accountEntityCaptor;

    private AccountEntity accountEntity;
    private AccountRequestDTO accountRequestDTO;
    private AccountResponseDTO accountResponseDTO;

    @BeforeEach
    void setUp() {
        accountEntity = new AccountEntity();
        accountEntity.setId(1L);
        accountEntity.setAccountNumber("1234567890");
        accountEntity.setAccountStatus(AccountStatus.ACTIVE);
        accountEntity.setUserId(1L);
        accountEntity.setBalance(100.0);

        accountRequestDTO = new AccountRequestDTO();
        accountRequestDTO.setAccountType("SAVINGS");
        accountRequestDTO.setAccountStatus("ACTIVE");
        accountRequestDTO.setUserId(1L);

        accountResponseDTO = new AccountResponseDTO();
        accountResponseDTO.setId(1L);
        accountResponseDTO.setAccountNumber("1234567890");
        accountResponseDTO.setAccountType("SAVINGS");
        accountResponseDTO.setAccountStatus(AccountStatus.ACTIVE);
        accountResponseDTO.setUserId(1L);
        accountResponseDTO.setBalance(100.0);
    }

    @Test
    void createAccount_shouldCreateAccountAndReturnResponse() {
        when(accountRepository.save(any(AccountEntity.class))).thenReturn(accountEntity);
        when(modelMapper.map(any(AccountEntity.class), eq(AccountResponseDTO.class))).thenReturn(accountResponseDTO);

        AccountResponseDTO result = accountService.createAccount(accountRequestDTO);

        verify(accountRepository).save(accountEntityCaptor.capture());
        assertThat(result).isEqualTo(accountResponseDTO);
        assertThat(accountEntityCaptor.getValue().getAccountNumber()).startsWith("12345");
    }

    @Test
    void deleteAccount_shouldDeleteAccountWhenExists() {
        when(accountRepository.findById(1L)).thenReturn(Optional.of(accountEntity));

        String result = accountService.deleteAccount(1L);

        verify(accountRepository).delete(accountEntity);
        assertThat(result).isEqualTo(SuccessMessageUtil.ACCOUNT_DELETED);
    }

    @Test
    void deleteAccount_shouldThrowExceptionWhenAccountNotFound() {
        when(accountRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(AccountNotFoundException.class, () -> accountService.deleteAccount(1L));
    }

    @Test
    void changeAccountType_shouldChangeAccountType() {
        when(accountRepository.findById(1L)).thenReturn(Optional.of(accountEntity));
        when(accountRepository.save(accountEntity)).thenReturn(accountEntity);
        when(modelMapper.map(accountEntity, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        AccountResponseDTO result = accountService.changeAccountType(1L, "CURRENT");

        verify(accountRepository).save(accountEntityCaptor.capture());
        assertThat(accountEntityCaptor.getValue().getAccountType()).isEqualTo("CURRENT");
        assertThat(result).isEqualTo(accountResponseDTO);
    }

    @Test
    void activateAccountIfEligible_shouldActivateAccountWhenEligible() {
        when(accountRepository.findById(1L)).thenReturn(Optional.of(accountEntity));
        when(accountRepository.save(accountEntity)).thenReturn(accountEntity);

        String result = accountService.activateAccountIfEligible(1L);

        verify(accountRepository).save(accountEntityCaptor.capture());
        assertThat(accountEntityCaptor.getValue().getAccountStatus()).isEqualTo(AccountStatus.ACTIVE);
        assertThat(result).isEqualTo(SuccessMessageUtil.ACCOUNT_ACTIVATED);
    }

    @Test
    void deactivateAccount_shouldDeactivateAccountWhenEligible() {
        accountEntity.setBalance(0.0);
        when(accountRepository.findById(1L)).thenReturn(Optional.of(accountEntity));
        when(accountRepository.save(accountEntity)).thenReturn(accountEntity);

        String result = accountService.deactivateAccount(1L);

        verify(accountRepository).save(accountEntityCaptor.capture());
        assertThat(accountEntityCaptor.getValue().getAccountStatus()).isEqualTo(AccountStatus.INACTIVE);
        assertThat(result).isEqualTo(SuccessMessageUtil.ACCOUNT_DEACTIVATED);
    }

    @Test
    void getAllAccounts_shouldReturnAllAccounts() {
        when(accountRepository.findAll()).thenReturn(Arrays.asList(accountEntity));
        when(modelMapper.map(accountEntity, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        List<AccountResponseDTO> result = accountService.getAllAccounts();

        assertThat(result).containsExactly(accountResponseDTO);
    }

    @Test
    void getAccountDetails_shouldReturnAccountDetailsWhenFound() {
        when(accountRepository.findById(1L)).thenReturn(Optional.of(accountEntity));
        when(modelMapper.map(accountEntity, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        AccountResponseDTO result = accountService.getAccountDetails(1L);

        assertThat(result).isEqualTo(accountResponseDTO);
    }

    @Test
    void searchAccountsByNumber_shouldReturnAccountWhenFound() {
        when(accountRepository.findByAccountNumber("1234567890")).thenReturn(accountEntity);
        when(modelMapper.map(accountEntity, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        AccountResponseDTO result = accountService.searchAccountsByNumber("1234567890");

        assertThat(result).isEqualTo(accountResponseDTO);
    }

    @Test
    void searchAccountsByNumber_shouldThrowExceptionWhenAccountNotFound() {
        when(accountRepository.findByAccountNumber("1234567890")).thenReturn(null);

        assertThrows(AccountNotFoundException.class, () -> accountService.searchAccountsByNumber("1234567890"));
    }

    @Test
    void getAllAccountsWithPagination_shouldReturnPagedAccounts() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<AccountEntity> accountPage = new PageImpl<>(Arrays.asList(accountEntity));
        when(accountRepository.findAll(pageable)).thenReturn(accountPage);
        when(modelMapper.map(accountEntity, AccountResponseDTO.class)).thenReturn(accountResponseDTO);

        Page<AccountResponseDTO> result = accountService.getAllAccounts(pageable);

        assertThat(result.getContent()).containsExactly(accountResponseDTO);
    }
}
