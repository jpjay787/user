package com.online.banking.account.repository;

import com.online.banking.account.model.AccountEntity;
import com.online.banking.account.model.AccountStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Transactional
class AccountRepositoryTest {

    @Autowired
    private AccountRepository accountRepository;

    @BeforeEach
    public void setup() {
        // Clean up existing data to avoid interference between tests
        accountRepository.deleteAll();

        AccountEntity account1 = new AccountEntity();
        account1.setAccountNumber("12345000001");
        account1.setAccountType("SAVINGS");
        account1.setAccountStatus(AccountStatus.ACTIVE);
        account1.setUserId(1L);
        account1.setBalance(5000.0);

        AccountEntity account2 = new AccountEntity();
        account2.setAccountNumber("12345000002");
        account2.setAccountType("CHECKING");
        account2.setAccountStatus(AccountStatus.INACTIVE);
        account2.setUserId(2L);
        account2.setBalance(0.0);

        accountRepository.save(account1);
        accountRepository.save(account2);
    }

    @Test
    void findByAccountNumber_shouldReturnAccount() {
        // When
        AccountEntity account = accountRepository.findByAccountNumber("12345000001");

        // Then
        assertNotNull(account);
        assertThat(account.getAccountNumber()).isEqualTo("12345000001");
        assertThat(account.getAccountStatus()).isEqualTo(AccountStatus.ACTIVE);
    }


    @Test
    void save_shouldStoreAccount() {
        // Given
        AccountEntity newAccount = new AccountEntity();
        newAccount.setAccountNumber("12345000003");
        newAccount.setAccountType("SAVINGS");
        newAccount.setAccountStatus(AccountStatus.ACTIVE);
        newAccount.setUserId(3L);
        newAccount.setBalance(10000.0);

        // When
        AccountEntity savedAccount = accountRepository.save(newAccount);

        // Then
        assertNotNull(savedAccount);
        assertThat(savedAccount.getId()).isNotNull();
        assertThat(savedAccount.getAccountNumber()).isEqualTo("12345000003");
    }


        @Test
        void findByAccountStatus_shouldReturnAccounts() {
            // When
            List<AccountEntity> activeAccounts = accountRepository.findByAccountStatus(AccountStatus.ACTIVE);

            // Then
            assertThat(activeAccounts).isNotEmpty();
            assertThat(activeAccounts.size()).isEqualTo(1); // Only one active account in setup
            assertThat(activeAccounts.get(0).getAccountNumber()).isEqualTo("12345000001");
        }

        @Test
        void findAll_shouldReturnAllAccounts() {
            // When
            List<AccountEntity> accounts = accountRepository.findAll();

            // Then
            assertThat(accounts).hasSize(2); // Two accounts in the setup
        }

        @Test
        void delete_shouldRemoveAccount() {
            // Given
            AccountEntity account = accountRepository.findByAccountNumber("12345000002");
            assertNotNull(account); // Check that the account exists

            // When
            accountRepository.delete(account);
            List<AccountEntity> remainingAccounts = accountRepository.findAll();

            // Then
            assertThat(remainingAccounts).hasSize(1); // One account should remain after deletion
            assertThat(remainingAccounts.get(0).getAccountNumber()).isEqualTo("12345000001");
        }
    }

