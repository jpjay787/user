CREATE TABLE account_entity (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    account_number VARCHAR(255) UNIQUE,
    account_type VARCHAR(255),
    account_status VARCHAR(20),
    user_id BIGINT UNIQUE, -- Foreign key reference to user_online_bank
    balance DOUBLE NOT NULL,
    CONSTRAINT fk_account_user FOREIGN KEY (user_id) REFERENCES user_online_bank(id)
);

