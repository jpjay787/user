package com.online.banking.account;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcccountsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcccountsApplication.class, args);
	}

}
