package com.online.banking.account.util;

public class SuccessMessageUtil {

    public static final String ACCOUNT_CREATED = "Account successfully created.";
    public static final String ACCOUNT_DELETED = "Account successfully deleted.";
    public static final String ACCOUNT_TYPE_CHANGED = "Account type successfully changed.";
    public static final String ACCOUNT_ACTIVATED = "Account successfully activated.";
    public static final String ACCOUNT_DEACTIVATED = "Account successfully deactivated.";

    public static final String ACCOUNT_RETRIEVED = "Account details retrieved successfully.";
}
