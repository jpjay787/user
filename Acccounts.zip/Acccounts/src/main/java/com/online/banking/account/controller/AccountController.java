package com.online.banking.account.controller;
import com.online.banking.account.dto.AccountRequestDTO;
import com.online.banking.account.dto.AccountResponseDTO;
import com.online.banking.account.service.AccountService;
import com.online.banking.account.util.SuccessMessageUtil;


import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @PostMapping
    public ResponseEntity<String> createAccount(@Valid @RequestBody AccountRequestDTO accountRequestDTO) {
        accountService.createAccount(accountRequestDTO);
        return new ResponseEntity<>(SuccessMessageUtil.ACCOUNT_CREATED, HttpStatus.CREATED);
    }

    @DeleteMapping("/{accountId}")
    public ResponseEntity<String> deleteAccount(@PathVariable Long accountId) {
        accountService.deleteAccount(accountId);
        return new ResponseEntity<>(SuccessMessageUtil.ACCOUNT_DELETED, HttpStatus.OK);
    }

    @PutMapping("/{accountId}/type")
    public ResponseEntity<String> changeAccountType(@PathVariable Long accountId,
                                                    @RequestBody String accountType) {
        accountService.changeAccountType(accountId, accountType);
        return new ResponseEntity<>(SuccessMessageUtil.ACCOUNT_TYPE_CHANGED, HttpStatus.OK);
    }

    @PutMapping("/{accountId}/activate")
    public ResponseEntity<String> activateAccountIfEligible(@PathVariable Long accountId) {
        accountService.activateAccountIfEligible(accountId);
        return ResponseEntity.ok("Activation process completed");
    }

    @PutMapping("/{accountId}/deactivate")
    public ResponseEntity<String> deactivateAccount(@PathVariable Long accountId) {
        accountService.deactivateAccount(accountId);
        return new ResponseEntity<>(SuccessMessageUtil.ACCOUNT_DEACTIVATED, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<Page<AccountResponseDTO>> getAllAccounts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {

        Pageable pageable = PageRequest.of(page, size,
                sortDir.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending());

        Page<AccountResponseDTO> accounts = accountService.getAllAccounts(pageable);
        return new ResponseEntity<>(accounts, HttpStatus.OK);
    }

    @GetMapping("/{accountId}")
    public ResponseEntity<AccountResponseDTO> getAccountDetails(@PathVariable Long accountId) {
        AccountResponseDTO accountResponseDTO = accountService.getAccountDetails(accountId);
        return new ResponseEntity<>(accountResponseDTO, HttpStatus.OK);
    }

    @GetMapping("/searchbyaccno")
    public ResponseEntity<AccountResponseDTO> searchAccountsByNumber(@RequestParam String accountNumber) {
        AccountResponseDTO account = accountService.searchAccountsByNumber(accountNumber);
        return new ResponseEntity<>(account, HttpStatus.OK);
    }
}
