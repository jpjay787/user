package com.online.banking.account.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AccountRequestDTO {
    private String accountNumber;
    private Long userId;
    @NotBlank(message = "AccountHolderName mandatory")
    private String accountHolderName;
    @NotBlank(message = "accountType mandatory")
    private String accountType;
    @NotNull(message = "AccountStatus mandatory")
    private String accountStatus;
    private double balance;
}
