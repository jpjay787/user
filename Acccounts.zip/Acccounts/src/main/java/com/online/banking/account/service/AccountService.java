package com.online.banking.account.service;

import com.online.banking.account.dto.AccountRequestDTO;
import com.online.banking.account.dto.AccountResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface AccountService {

    AccountResponseDTO createAccount(AccountRequestDTO accountRequestDTO);
    String deleteAccount(Long accountId);
    AccountResponseDTO changeAccountType(Long accountId, String accountType);
    String activateAccountIfEligible(Long accountId);
    String deactivateAccount(Long accountId);
    Page<AccountResponseDTO> getAllAccounts(Pageable pageable);

    List<AccountResponseDTO> getAllAccounts();

    AccountResponseDTO getAccountDetails(Long accountId);
    AccountResponseDTO searchAccountsByNumber(String accountNumber);

}
