package com.online.banking.account.model;

public enum AccountStatus {
    ACTIVE,
    INACTIVE
}
