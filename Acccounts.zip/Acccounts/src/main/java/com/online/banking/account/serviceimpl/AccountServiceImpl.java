package com.online.banking.account.serviceimpl;

import com.online.banking.account.dto.AccountRequestDTO;
import com.online.banking.account.dto.AccountResponseDTO;
import com.online.banking.account.exception.AccountNotFoundException;
import com.online.banking.account.model.AccountEntity;
import com.online.banking.account.model.AccountStatus;
import com.online.banking.account.repository.AccountRepository;
import com.online.banking.account.service.AccountService;
import com.online.banking.account.util.SuccessMessageUtil;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final ModelMapper modelMapper;
    private static final String COMMON_PREFIX = "12345";
    private static final Random RANDOM = new Random();
    public AccountServiceImpl(AccountRepository accountRepository, ModelMapper modelMapper) {
        this.accountRepository = accountRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public AccountResponseDTO createAccount(AccountRequestDTO accountRequestDTO) {
        AccountEntity accountEntity = new AccountEntity();
        accountEntity.setAccountType(accountRequestDTO.getAccountType());
        accountEntity.setAccountStatus(AccountStatus.valueOf(accountRequestDTO.getAccountStatus()));
        accountEntity.setUserId(accountRequestDTO.getUserId());
        accountEntity.setBalance(0.0); // Default balance

        String accountNumber = generateAccountNumber();
        accountEntity.setAccountNumber(accountNumber);

        accountRepository.save(accountEntity);
        return modelMapper.map(accountEntity, AccountResponseDTO.class);
    }

    @Override
    public String deleteAccount(Long accountId) {
        AccountEntity accountEntity = getAccountById(accountId);
        accountRepository.delete(accountEntity);
        return SuccessMessageUtil.ACCOUNT_DELETED;
    }

    @Override
    public AccountResponseDTO changeAccountType(Long accountId, String accountType) {
        AccountEntity accountEntity = getAccountById(accountId);
        accountEntity.setAccountType(accountType);
        accountRepository.save(accountEntity);
        return modelMapper.map(accountEntity, AccountResponseDTO.class);
    }

    @Override
    public String activateAccountIfEligible(Long accountId) {
        AccountEntity accountEntity = getAccountById(accountId);
        if (accountEntity.getBalance() > 0) {
            accountEntity.setAccountStatus(AccountStatus.ACTIVE);
            accountRepository.save(accountEntity);
            return SuccessMessageUtil.ACCOUNT_ACTIVATED;
        } else {
            return "Account cannot be activated due to insufficient balance.";
        }
    }

    @Override
    public String deactivateAccount(Long accountId) {
        AccountEntity accountEntity = getAccountById(accountId);
        if (accountEntity.getBalance() <= 0) {
            accountEntity.setAccountStatus(AccountStatus.INACTIVE);
            accountRepository.save(accountEntity);
            return SuccessMessageUtil.ACCOUNT_DEACTIVATED;
        } else {
            return "Account cannot be deactivated because it has a positive balance.";
        }
    }

    @Override
    public List<AccountResponseDTO> getAllAccounts() {
        List<AccountEntity> accounts = accountRepository.findAll();
        return accounts.stream()
                .map(account -> modelMapper.map(account, AccountResponseDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public AccountResponseDTO getAccountDetails(Long accountId) {
        AccountEntity accountEntity = getAccountById(accountId);
        return modelMapper.map(accountEntity, AccountResponseDTO.class);
    }

    @Override
    public AccountResponseDTO searchAccountsByNumber(String accountNumber) {
        AccountEntity accountEntity = accountRepository.findByAccountNumber(accountNumber);
        if (accountEntity == null) {
            throw new AccountNotFoundException("Account not found with account number: " + accountNumber);
        }
        return modelMapper.map(accountEntity, AccountResponseDTO.class);
    }

    @Override
    public Page<AccountResponseDTO> getAllAccounts(Pageable pageable) {
        return accountRepository.findAll(pageable)
                .map(account -> modelMapper.map(account, AccountResponseDTO.class));
    }

    private AccountEntity getAccountById(Long accountId) {
        return accountRepository.findById(accountId)
                .orElseThrow(() -> new AccountNotFoundException("Account not found with id: " + accountId));
    }

    private String generateAccountNumber() {
        int randomNumber = RANDOM.nextInt(1000000);
        return COMMON_PREFIX + String.format("%06d", randomNumber);
    }
}
