package com.online.banking.account.dto;

import com.online.banking.account.model.AccountStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountResponseDTO {
    private Long id;
    private String accountNumber;
    private String accountType;
    private AccountStatus accountStatus;
    private Long userId;
    private double balance;
    private String message;
}
