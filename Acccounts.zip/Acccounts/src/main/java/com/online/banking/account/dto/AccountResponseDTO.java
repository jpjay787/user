package com.online.banking.account.dto;

import com.online.banking.account.model.AccountStatus;
import jdk.jshell.Snippet;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AccountResponseDTO {
    private Long id;
    private String accountNumber;
    private String accountType;
    private AccountStatus accountStatus;
    private Long userId;
    private double balance;
    private String message;


}
