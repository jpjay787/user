package com.online.banking.cards.repository;

import com.online.banking.cards.model.CardEntity;
import com.online.banking.cards.model.CardType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class CardRepositoryTest {

    @Autowired
    private CardRepository cardRepository;

    private CardEntity cardEntity;

    @BeforeEach
    public void setUp() {
        cardEntity = CardEntity.builder()
                .userId(1L)
                .cardType(CardType.DEBIT)
                .cardNumber(1L)
                .issueDate(LocalDate.now())
                .expiryDate(LocalDate.now().plusYears(5))
                .isActive(false)
                .isBlocked(false)
                .transactionLimit(10000)
                .pin("1234")
                .cardHolderName("John Doe")
                .build();
        cardRepository.save(cardEntity);
    }

    @Test
    public void testFindByCardNumber() {
        Optional<CardEntity> foundCard = cardRepository.findByCardNumber(1L);
        assertThat(foundCard).isPresent();
        assertThat(foundCard.get().getCardHolderName()).isEqualTo("John Doe");
    }

    @Test
    public void testFindAll() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<CardEntity> cardPage = cardRepository.findAll(pageable);
        assertThat(cardPage).isNotEmpty();
        assertThat(cardPage.getContent().get(0).getCardHolderName()).isEqualTo("John Doe");
    }
}
