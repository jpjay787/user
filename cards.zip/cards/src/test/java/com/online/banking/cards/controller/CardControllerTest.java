package com.online.banking.cards.controller;

import com.online.banking.cards.dto.CardRequestDto;
import com.online.banking.cards.dto.CardResponseDto;
import com.online.banking.cards.service.CardService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class CardControllerTest {

    @Mock
    private CardService cardService;

    @InjectMocks
    private CardController cardController;

    private CardRequestDto cardRequestDto;
    private CardResponseDto cardResponseDto;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        cardRequestDto = CardRequestDto.builder()
                .userId(1L)
                .cardType(null)  // Adjust this as needed for your test
                .transactionLimit(5000)
                .cardHolderName("John Doe")
                .build();

        cardResponseDto = CardResponseDto.builder()
                .id(1L)
                .cardNumber(1234567890L)
                .isActive(true)
                .isBlocked(false)
                .issueDate(LocalDate.now())
                .expiryDate(LocalDate.now().plusYears(3))
                .transactionLimit(5000)
                .cardHolderName("John Doe")
                .build();
    }

    @Test
    public void testIssueCard() {
        when(cardService.issueCard(any(CardRequestDto.class))).thenReturn(cardResponseDto);

        ResponseEntity<CardResponseDto> response = cardController.issueCard(cardRequestDto);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(cardResponseDto, response.getBody());
    }

    @Test
    public void testActivateCard() {
        when(cardService.activateCard(anyString())).thenReturn(cardResponseDto);

        ResponseEntity<CardResponseDto> response = cardController.activateCard("1234567890");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(cardResponseDto, response.getBody());
    }

    @Test
    public void testBlockCard() {
        when(cardService.blockCard(anyString())).thenReturn(cardResponseDto);

        ResponseEntity<CardResponseDto> response = cardController.blockCard("1234567890");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(cardResponseDto, response.getBody());
    }

    @Test
    public void testSetTransactionLimit() {
        when(cardService.setTransactionLimit(anyString(), anyInt())).thenReturn(cardResponseDto);

        ResponseEntity<CardResponseDto> response = cardController.setTransactionLimit("1234567890", 6000);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(cardResponseDto, response.getBody());
    }

    @Test
    public void testGeneratePin() {
        when(cardService.generatePin(anyString())).thenReturn(cardResponseDto);

        ResponseEntity<CardResponseDto> response = cardController.generatePin("1234567890");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(cardResponseDto, response.getBody());
    }

    @Test
    public void testGetAllCards() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<CardResponseDto> page = new PageImpl<>(Collections.singletonList(cardResponseDto));

        when(cardService.getAllCards(any(Pageable.class))).thenReturn(page);

        ResponseEntity<Page<CardResponseDto>> response = cardController.getAllCards(pageable);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(page, response.getBody());
    }
}
