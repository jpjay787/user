package com.online.banking.cards.serviceImpl;

import com.online.banking.cards.dto.CardRequestDto;
import com.online.banking.cards.dto.CardResponseDto;
import com.online.banking.cards.exception.CardNotFoundException;
import com.online.banking.cards.model.CardEntity;
import com.online.banking.cards.model.CardType;
import com.online.banking.cards.repository.CardRepository;
import com.online.banking.cards.serviceimpl.CardServiceImpl;
import com.online.banking.cards.util.CardUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CardServiceImplTest {

    @Mock
    private CardRepository cardRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private CardServiceImpl cardService;

    private CardEntity cardEntity;
    private CardResponseDto cardResponseDto;
    private CardRequestDto cardRequestDto;

    @BeforeEach
    public void setUp() {
        cardEntity = CardEntity.builder()
                .id(1L)
                .cardNumber(123456789L)
                .isActive(false)
                .isBlocked(false)
                .issueDate(LocalDate.now())
                .expiryDate(LocalDate.now().plusYears(5))
                .transactionLimit(5000)
                .pin("1234")
                .cardHolderName("John Doe")
                .build();

        cardResponseDto = CardResponseDto.builder()
                .id(1L)
                .cardNumber(123456789L)
                .isActive(false)
                .isBlocked(false)
                .issueDate(LocalDate.now())
                .expiryDate(LocalDate.now().plusYears(5))
                .transactionLimit(5000)
                .cardHolderName("John Doe")
                .build();

        cardRequestDto = CardRequestDto.builder()
                .userId(1L)
                .cardType(CardType.DEBIT)
                .transactionLimit(5000)
                .cardHolderName("John Doe")
                .build();
    }

    @Test
    public void issueCard_ShouldReturnCardResponseDto() {
        when(cardRepository.save(any(CardEntity.class))).thenReturn(cardEntity);
        when(modelMapper.map(any(CardEntity.class), eq(CardResponseDto.class))).thenReturn(cardResponseDto);

        CardResponseDto response = cardService.issueCard(cardRequestDto);

        assertNotNull(response);
        assertEquals(cardResponseDto.getId(), response.getId());
        verify(cardRepository, times(1)).save(any(CardEntity.class));
    }

    @Test
    public void getAllCards_ShouldReturnPagedCardResponseDto() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<CardEntity> cardPage = new PageImpl<>(Arrays.asList(cardEntity), pageable, 1);
        Page<CardResponseDto> responsePage = new PageImpl<>(Arrays.asList(cardResponseDto), pageable, 1);

        when(cardRepository.findAll(pageable)).thenReturn(cardPage);
        when(modelMapper.map(any(CardEntity.class), eq(CardResponseDto.class))).thenReturn(cardResponseDto);

        Page<CardResponseDto> response = cardService.getAllCards(pageable);

        assertNotNull(response);
        assertEquals(1, response.getTotalElements());
        assertEquals(cardResponseDto.getCardNumber(), response.getContent().get(0).getCardNumber());
        verify(cardRepository, times(1)).findAll(pageable);
    }

    @Test
    public void activateCard_ShouldThrowCardNotFoundException() {
        when(cardRepository.findByCardNumber(anyLong())).thenReturn(Optional.empty());

        assertThrows(CardNotFoundException.class, () -> cardService.activateCard("123456789"));

        verify(cardRepository, times(1)).findByCardNumber(anyLong());
    }

    @Test
    public void blockCard_ShouldThrowCardNotFoundException() {
        when(cardRepository.findByCardNumber(anyLong())).thenReturn(Optional.empty());

        assertThrows(CardNotFoundException.class, () -> cardService.blockCard("123456789"));

        verify(cardRepository, times(1)).findByCardNumber(anyLong());
    }

    @Test
    public void setTransactionLimit_ShouldThrowCardNotFoundException() {
        when(cardRepository.findByCardNumber(anyLong())).thenReturn(Optional.empty());

        assertThrows(CardNotFoundException.class, () -> cardService.setTransactionLimit("123456789", 10000));

        verify(cardRepository, times(1)).findByCardNumber(anyLong());
    }

    @Test
    public void generatePin_ShouldThrowCardNotFoundException() {
        when(cardRepository.findByCardNumber(anyLong())).thenReturn(Optional.empty());

        assertThrows(CardNotFoundException.class, () -> cardService.generatePin("123456789"));

        verify(cardRepository, times(1)).findByCardNumber(anyLong());
    }
}
