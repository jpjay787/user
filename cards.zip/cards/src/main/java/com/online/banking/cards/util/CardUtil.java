package com.online.banking.cards.util;

import java.util.Random;

public class CardUtil {
    public static Long generateCardNumber() {
        Random random = new Random();
        long min = 10000000000L;
        long max = 99999999999L;
        return min + (long) (random.nextDouble() * (max - min));
    }
}





