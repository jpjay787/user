package com.online.banking.cards.dto;

import com.online.banking.cards.model.CardEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CardResponseDto {

    private Long id;
    private Long cardNumber;
    private boolean isActive;
    private boolean isBlocked;
    private LocalDate issueDate;
    private LocalDate expiryDate;
    private int transactionLimit;
    private String cardHolderName;
    private int pin;
}
