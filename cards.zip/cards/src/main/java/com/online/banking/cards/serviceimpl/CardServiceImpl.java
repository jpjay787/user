package com.online.banking.cards.serviceimpl;

import com.online.banking.cards.dto.CardRequestDto;
import com.online.banking.cards.dto.CardResponseDto;
import com.online.banking.cards.exception.CardNotFoundException;
import com.online.banking.cards.model.CardEntity;
import com.online.banking.cards.repository.CardRepository;
import com.online.banking.cards.service.CardService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Random;

import static com.online.banking.cards.util.CardUtil.generateCardNumber;

@Service
@RequiredArgsConstructor
public class CardServiceImpl implements CardService {
    private final CardRepository cardRepository;
    private final ModelMapper modelMapper;

    @Override
    public CardResponseDto issueCard(CardRequestDto request) {
        CardEntity card = CardEntity.builder()
                .userId(request.getUserId())
                .cardType(request.getCardType())
                .cardNumber(generateCardNumber())
                .issueDate(LocalDate.now())
                .expiryDate(LocalDate.now().plusYears(5))
                .isActive(false)
                .isBlocked(false)
                .transactionLimit(request.getTransactionLimit())
                .pin(generatePin())
                .cardHolderName(request.getCardHolderName())
                .build();

        CardEntity savedCard = cardRepository.save(card);
        return modelMapper.map(savedCard, CardResponseDto.class);
    }

    @Override
    public CardResponseDto activateCard(String cardNumber) {
        return cardRepository.findByCardNumber(Long.parseLong(cardNumber))
                .map(card -> {
                    card.setActive(true);
                    CardEntity updatedCard = cardRepository.save(card);
                    return modelMapper.map(updatedCard, CardResponseDto.class);
                })
                .orElseThrow(() -> new CardNotFoundException("Card not found"));
    }

    @Override
    public CardResponseDto blockCard(String cardNumber) {
        return cardRepository.findByCardNumber(Long.parseLong(cardNumber))
                .map(card -> {
                    card.setBlocked(true);
                    CardEntity updatedCard = cardRepository.save(card);
                    return modelMapper.map(updatedCard, CardResponseDto.class);
                })
                .orElseThrow(() -> new CardNotFoundException("Card not found"));
    }

    @Override
    public CardResponseDto setTransactionLimit(String cardNumber, int newLimit) {
        return cardRepository.findByCardNumber(Long.parseLong(cardNumber))
                .map(card -> {
                    card.setTransactionLimit(newLimit);
                    CardEntity updatedCard = cardRepository.save(card);
                    return modelMapper.map(updatedCard, CardResponseDto.class);
                })
                .orElseThrow(() -> new CardNotFoundException("Card not found"));
    }

    @Override
    public CardResponseDto generatePin(String cardNumber) {
        return cardRepository.findByCardNumber(Long.parseLong(cardNumber))
                .map(card -> {
                    String newPin = generatePin();
                    card.setPin(newPin);
                    CardEntity updatedCard = cardRepository.save(card);
                    return modelMapper.map(updatedCard, CardResponseDto.class);
                })
                .orElseThrow(() -> new CardNotFoundException("Card not found"));
    }

    @Override
    public Page<CardResponseDto> getAllCards(Pageable pageable) {
        return cardRepository.findAll(pageable)
                .map(card -> modelMapper.map(card, CardResponseDto.class));
    }
    private String generatePin() {
        Random random = new Random();
        int pin = 1000 + random.nextInt(9000); // Generates a 4-digit pin
        return String.valueOf(pin);
    }
}
