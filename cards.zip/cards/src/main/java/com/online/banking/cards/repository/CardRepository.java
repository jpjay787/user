package com.online.banking.cards.repository;

import com.online.banking.cards.model.CardEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CardRepository extends JpaRepository<CardEntity, Long> {
    Optional<CardEntity> findByCardNumber(Long cardNumber);
    Page<CardEntity> findAll(Pageable pageable);
}

