package com.online.banking.cards.service;

import com.online.banking.cards.dto.CardRequestDto;
import com.online.banking.cards.dto.CardResponseDto;
import com.online.banking.cards.model.CardEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface CardService {
    CardResponseDto issueCard(CardRequestDto request);
    CardResponseDto activateCard(String cardNumber);
    CardResponseDto blockCard(String cardNumber);
    CardResponseDto setTransactionLimit(String cardNumber, int newLimit);
    CardResponseDto generatePin(String cardNumber);
    Page<CardResponseDto> getAllCards(Pageable pageable);
}
