package com.online.banking.cards.exception;

public class CardUpdateException extends RuntimeException {
    public CardUpdateException(String message) {
        super(message);
    }
}

