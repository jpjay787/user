package com.online.banking.cards.exception;

public class CardAlreadyActiveException extends RuntimeException {
    public CardAlreadyActiveException(String message) {
        super(message);
    }
}
