package com.online.banking.cards.model;
import lombok.*;

import jakarta.persistence.*;
import java.time.LocalDate;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cardss")
public class CardEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;

    @Enumerated(EnumType.STRING)
    private CardType cardType;
    private String cardHolderName;
    private Long cardNumber;
    private LocalDate issueDate;
    private LocalDate expiryDate;
    private boolean isActive;
    private boolean isBlocked;
    private int transactionLimit;
    @Setter
    private String pin;

}
