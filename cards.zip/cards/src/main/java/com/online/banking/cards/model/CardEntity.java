package com.online.banking.cards.model;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cardss")
public class CardEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;

    @Enumerated(EnumType.STRING)
    private CardType cardType;
    private String cardHolderName;
    private Long cardNumber;
    private LocalDate issueDate;
    private LocalDate expiryDate;
    private boolean isActive;
    private boolean isBlocked;
    private int transactionLimit;
    private String pin;
}
