package com.online.banking.cards.controller;

import com.online.banking.cards.dto.CardRequestDto;
import com.online.banking.cards.dto.CardResponseDto;
import com.online.banking.cards.service.CardService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cards")
@RequiredArgsConstructor
public class CardController {
    private final CardService cardService;

    @PostMapping("/issue")
    public ResponseEntity<CardResponseDto> issueCard(@Valid @RequestBody CardRequestDto request) {
        CardResponseDto response = cardService.issueCard(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PatchMapping("/activate/{cardNumber}")
    public ResponseEntity<CardResponseDto> activateCard(@PathVariable String cardNumber) {
        CardResponseDto response = cardService.activateCard(cardNumber);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PatchMapping("/block/{cardNumber}")
    public ResponseEntity<CardResponseDto> blockCard(@PathVariable String cardNumber) {
        CardResponseDto response = cardService.blockCard(cardNumber);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PatchMapping("/transaction-limit/{cardNumber}")
    public ResponseEntity<CardResponseDto> setTransactionLimit(
            @PathVariable String cardNumber,
            @RequestParam int newLimit) {
        CardResponseDto response = cardService.setTransactionLimit(cardNumber, newLimit);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PatchMapping("/generate-pin/{cardNumber}")
    public ResponseEntity<CardResponseDto> generatePin(@PathVariable String cardNumber) {
        CardResponseDto response = cardService.generatePin(cardNumber);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<Page<CardResponseDto>> getAllCards(Pageable pageable) {
        Page<CardResponseDto> cards = cardService.getAllCards(pageable);
        return new ResponseEntity<>(cards, HttpStatus.OK);
    }
}
