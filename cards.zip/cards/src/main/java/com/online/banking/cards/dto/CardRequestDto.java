package com.online.banking.cards.dto;

import com.online.banking.cards.model.CardType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class CardRequestDto {
    @NotNull(message = "UserIs is Mandatory")
    private Long userId;

    private CardType cardType;
    @NotNull(message = "TransactionLimit is Mandatory")
    private int transactionLimit;
    @NotNull(message = "cardHolderName is Mandatory")
    private String cardHolderName;
}

