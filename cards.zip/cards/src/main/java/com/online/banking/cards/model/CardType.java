package com.online.banking.cards.model;
public enum CardType {
    DEBIT,
    CREDIT
}
